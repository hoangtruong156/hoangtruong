<?php


header('Location: http://localhost/DoAnBanDienThoai/');

?>