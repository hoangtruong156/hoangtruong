<?php
class Giohang extends Db{
	
	public function timgiohang($n)
	{
		$sql="SELECT * FROM `giohang` WHERE `makh`=$n";
		return $this->select($sql);	
	}
	public function taogiohang($n)
	{
		$sql="INSERT INTO `giohang`(`makh`) VALUES ($n)";
		return $this->select($sql);	
	}
	public function giohangmoitao()
	{
		$sql="SELECT * FROM `giohang` ORDER BY `giohang`.`ngaytao` DESC LIMIT 1";
		return $this->select($sql);
	}

	public function timchitietgiohang($n)
	{
		$sql="SELECT * FROM `chitietgiohang` WHERE `magiohang`=$n";
		return $this->select($sql);	
	}
	public function taochitietgiohang($a,$b,$c)
	{
		$sql="INSERT INTO `chitietgiohang`(`magiohang`, `masp`, `soluong`) VALUES ($a,$b,$c)";
		return $this->select($sql);
	}
	public function xoachitietgiohang($a,$b)
	{		
		
		$sql="DELETE FROM `chitietgiohang` WHERE `chitietgiohang`.`magiohang` = $a AND `chitietgiohang`.`masp`=$b" ;
		return $this->select($sql);
	}
	public function suachitietgiohang($a,$b,$c)
	{
		
		$sql="UPDATE `chitietgiohang` SET `soluong` = $c WHERE `chitietgiohang`.`magiohang` = $a AND `chitietgiohang`.`masp`=$b;";
		return $this->select($sql);
	}
	


}
?>