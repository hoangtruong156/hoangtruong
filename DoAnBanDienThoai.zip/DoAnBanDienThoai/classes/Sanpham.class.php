<?php
class Sanpham extends Db{
	public function timtheoten($n)
	{
		$sql="select * from sanpham where tensp like '%$n%'	 or giasp like '%$n%'";
		return $this->select($sql);	
	}
	
	public function timtheomasp($n)
	{
		$sql="select * from sanpham where masp = $n ";
		return $this->select($sql);	
	}
	
	public function timtheomucgia($n)
	{
		$sql="select * from sanpham where giasp=$n";
		return $this->select($sql);
	}
	public function duoi3t()
	{
		$sql="select * from sanpham where giasp < 3000000 ";
		return $this->select($sql);	
	}
	public function duoi6t()
	{
		$sql="select * from sanpham where giasp >= 3000000 and giasp <6000000 ";
		return $this->select($sql);	
	}
	public function duoi10t()
	{
		$sql="select * from sanpham where giasp < 10000000 and giasp >=6000000 ";
		return $this->select($sql);	
	}
	public function duoi15t()
	{
		$sql="select * from sanpham where giasp >= 10000000 and giasp <15000000 ";
		return $this->select($sql);	
	}
	public function tren15t()
	{
		$sql="select * from sanpham where giasp >= 15000000 ";
		return $this->select($sql);	
	}
	public function timtheomansx($n,$m)
	{
		$sql="select * from sanpham where mansx =$n and masp !=$m  order by rand()  	LIMIT 0,4";
		return $this->select($sql);	
	}
	public function timtheomansxall($n)
	{
		$sql="select * from sanpham where mansx =$n";
		return $this->select($sql);	

	}
	public function getAll()
	{
		$sql="select * from sanpham ";
		return $this->select($sql);
	}
}
?>