<div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>VỀ CHÚNG TÔI</h4>
						<ul>
						<li><a href="#">Giới thiệu về TT Mobile</a></li>
						<li><a href="#">Chính sách bảo hành</a></li>
						<li><a href="#">Hướng dẫn mua hàng</a></li>
						<li><a href="#">Điều khoản sử dụng</a></li>
						<li><a href="#"><span>Liên hệ</span></a></li>
						<li><iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FPhoneStore-Shop-105112544306538%2F&tabs=timeline&width=340&height=222&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=397611887543895" width="220" height="180/" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe></li>
						</ul>
					</div>
				
				<div class="col_1_of_4 span_1_of_4">
					<h4>TÀI KHOẢN CỦA TÔI</h4>
						<ul>
							<li><a href="contact.html">Đăng ký</a></li>
							<li><a href="#">View Cart</a></li>
							<li><a href="#">Giỏ hàng của tôi</a></li>
							<li><a href="faq.html">Trợ giúp</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>TÀI KHOẢN CỦA TÔI</h4>
						<ul>
							<li><a href="contact.html">Đăng ký</a></li>
							<li><a href="#">View Cart</a></li>
							<li><a href="#">Giỏ hàng của tôi</a></li>
							<li><a href="faq.html">Trợ giúp</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>THÔNG TIN LIÊN LẠC</h4>
						<ul>
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.9551758726916!2d106.67572221401979!3d10.737938192347627!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752fad0158a09f%3A0xfd0a6159277a3508!2zMTgwIMSQxrDhu51uZyBDYW8gTOG7lywgUGjGsOG7nW5nIDQsIFF14bqtbiA4LCBI4buTIENow60gTWluaCwgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1575257451125!5m2!1svi!2s" width="350" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
						</ul>
						
				</div>
			</div>
			<div class="copy_right">
				<p>&copy; 2019 Smart Store. All Rights Reserved</a> </p>
		   </div>
     </div>
</div>