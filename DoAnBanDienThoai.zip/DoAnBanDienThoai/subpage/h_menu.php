<div class="h_menu">
		<a id="touch-menu" class="mobile-menu" href="#">Menu</a>
		<nav>
		<ul class="menu list-unstyled">
			<li><a href="index.php">TRANG CHỦ</a></li>
			<li class="activate"><a href="trangtimkiem.php?timkiem=Tìm+kiếm+sản+phẩm">ĐIỆN THOẠI</a>

				<ul class="sub-menu list-unstyled">
				 <div class="nag-mother-list">
				   <div class="navg-drop-main">
					<div class="nav-drop">
						<li><a href="trangtimkiem.php?timkiem=Apple">apple(Iphone)</a></li>
						<li><a href="trangtimkiem.php?timkiem=Oppo">Oppo</a></li>		
					</div>
					<div class="nav-drop">
						<li><a href="trangtimkiem.php?timkiem=Samsung">Samsung</a></li>	
						<li><a href="trangtimkiem.php?timkiem=Honor">Honor</a></li>
						
					</div>
					<div class="nav-drop"> 
						<li><a href="trangtimkiem.php?timkiem=Vsmart">Vsmart</a></li>
						<li><a href="trangtimkiem.php?timkiem=Huawei">Huawei</a></li>
					</div>
					<div class="nav-drop">  
						<li><a href="trangtimkiem.php?timkiem=Xiaomi">Xiaomi</a></li>
						<li><a href="trangtimkiem.php?timkiem=Realme">Realme</a></li>
					</div>
				 </div>
				</div>
			</ul>
			</li>
			<li><a href="#">MỨC GIÁ</a>			
				<ul class="sub-menu list-unstyled sub-menu2" style="width: 150px;">
				  <div class="navg-drop-main">
						<div class="nav-drop " style="width: 140px;"> 
							<li><a href="trangtimkiem.php?timkiem=3t">Dưới 3 triệu</a></li>
							<li><a href="trangtimkiem.php?timkiem=6t">3-6 triệu</a></li>
							<li><a href="trangtimkiem.php?timkiem=10t">6-10 triệu</a></li>					
							<li><a href="trangtimkiem.php?timkiem=15t">10-15 triệu</a></li>
							<li><a href="trangtimkiem.php?timkiem=15tt">Trên 15 triệu</a></li>
							
						</div>
					</div>
				</ul>
			</li>		
			<li><a href="#">DỊCH VỤ</a>
				<ul class="sub-menu list-unstyled sub-menu3">
				  <div class="navg-drop-main">
					<div class="nav-drop"> 
						<li><a href="products.html">Product 4</a></li>
						<li><a href="products.html">Product 5</a></li>
						<li><a href="products.html">Product 6</a></li>
		
						
					</div>
					<div class="nav-drop"> 
						<li><a href="products.html">Product 4</a></li>
						<li><a href="products.html">Product 5</a></li>
						<li><a href="products.html">Product 6</a></li>
								
					</div>
					<div class="nav-drop"> 
						<li><a href="products.html">Product 4</a></li>
						<li><a href="products.html">Product 5</a></li>
						<li><a href="products.html">Product 6</a></li>
					</div>
					<div class="nav-drop"> 
						<li><a href="products.html">Product 4</a></li>
						<li><a href="products.html">Product 5</a></li>
						<li><a href="products.html">Product 6</a></li>
					</div>
					<div class="clear"> </div>
				 </div>
			  </ul>
			</li>
			<li><a href="quanlygiohang.php">Đặt hàng</a></li>
			<li><a href="#">GIAO HÀNG</a></li>
			<li><a href="faq.html">TIN TỨC</a></li>
			<li><a href="contact.html">LIÊN HỆ</a></li>
			<div class="clear"> </div>
		</ul>
		</nav> 
		<script src="js/menu.js" type="text/javascript"></script>
	</div>
		