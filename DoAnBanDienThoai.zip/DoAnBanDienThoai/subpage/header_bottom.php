<div class="header_bottom">		
		   <!-- FlexSlider -->
              <section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<li><img src="images/01.jpg" alt=""/></li>
						<li><img src="images/02.jpg" alt=""/></li>
						<li><img src="images/03.jpg" alt=""/></li>
						<li><img src="images/04.jpg" alt=""/></li>
						
				    </ul>
				  </div>
	      </section>
<!-- FlexSlider -->
	    
	  <div class="clear"></div>
  </div>	